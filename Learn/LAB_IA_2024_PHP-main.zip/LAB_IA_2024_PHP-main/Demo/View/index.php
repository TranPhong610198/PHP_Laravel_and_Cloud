<?php
echo("Hello world!");