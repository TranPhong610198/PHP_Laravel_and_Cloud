<?php
/* Connection parameters */
$host = 'mysql:host=localhost;dbname=test';
$user = 'root';
$password = 'password';
/* Connect to the database */
$pdo = new PDO($host, $user, $password);
?>